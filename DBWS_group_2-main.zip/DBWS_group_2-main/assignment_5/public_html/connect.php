<?php
$servername = "localhost"; // Change this to your server name
$username = "amartirosyan"; // Change this to your MySQL username
$password = "BTQOgZ"; // Change this to your MySQL password
$dbname = "Group-2"; // Change this to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
