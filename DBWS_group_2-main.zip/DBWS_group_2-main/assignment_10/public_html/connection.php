<?php 
	$conn = mysqli_connect("localhost", "root", "", "electric_cars");
?>