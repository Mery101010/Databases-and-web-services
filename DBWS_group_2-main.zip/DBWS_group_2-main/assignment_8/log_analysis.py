import pandas as pd
import re

log_regex = '([(\d\.)]+) - - \[(.*?)\] "(.*?)" (\d+) (\d+) "(.*?)" "(.*?)"'
log_regex_v2 = '([(\d\.)]+) - - \[(.*?)\] "(.*?)" (\d+) - "(.*?)" "(.*?)"'
log_regex_v3 = '([(\d\.)]+) - - \[(.*?)\] "(.*?)" (\d+) (\d+)'
log_regex_v4 = '([(\d\.)]+) - - \[(.*?)\] "(.*?)" (\d+) -'
error_regex = '\[(.*)?\] \[(.*?)\] \[(.*?)\](.*?) \[(.*?)\] (.+)'
error_regex_v2 = '\[(.*)?\] \[(.*?)\] \[(.*?)\] \[(.*?)\] (.+)'

with open('/var/log/apache2/access_log') as f:
    lines = f.readlines()
    data = []
    columns = ['ip', 'datetime', 'route', 'status', 'size', 'file', 'user_agent']
    for line in lines:
        try:
            if re.match(log_regex, line):
                data.append(re.match(log_regex, line).groups())
            elif re.match(log_regex_v2, line):
                row = list(re.match(log_regex_v2, line).groups())
                row.insert(4, 0)
                data.append(row)
            elif re.match(log_regex_v3, line):
                data.append(re.match(log_regex_v3, line).groups() + ('', ''))
            else:
                data.append(re.match(log_regex_v4, line).groups() + (0, '', ''))
        except Exception as e:
            pass
    data = pd.DataFrame(data, columns=columns)

my_data = data[data['route'].str.contains("~amartirosy")]

def get_browser(user_agent):
    if 'Firefox' in user_agent:
        return 'Firefox'
    elif 'Chrome' in user_agent:
        return 'Chrome'
    elif 'Safari' in user_agent:
        return 'Safari'
    elif 'Opera' in user_agent:
        return 'Opera'
    elif 'Edge' in user_agent:
        return 'Edge'
    elif 'MSIE' in user_agent:
        return 'Internet Explorer'
    else:
        return 'Other'
my_data['browser'] = my_data['user_agent'].apply(get_browser)

def get_page(file):
    return file.split(' HTTP')[0].split('/')[-1]
my_data['page'] = my_data['route'].apply(get_page)

my_data['datetime'] = pd.to_datetime(my_data['datetime'], format='%d/%b/%Y:%H:%M:%S %z')
my_data = my_data[['datetime', 'page', 'browser', 'ip']]
my_data.to_csv('logs.csv', index=False)

with open('/var/log/apache2/error_log') as f:
    lines = f.readlines()
    error_data = []
    columns = ['date', 'error_type', 'process', 'er','ip', 'description']
    for line in lines:
        try:
            if re.match(error_regex, line):
                error_data.append(re.match(error_regex, line).groups())
            elif re.match(error_regex_v2, line):
                row = re.match(error_regex_v2, line).groups()
                row.insert(3, '')
                error_data.append(row)
        except Exception as e:
            pass
    error_data = pd.DataFrame(error_data, columns=columns)

my_errors = error_data[error_data['description'].str.contains('amartirosy')]

my_errors = my_errors[['date', 'ip', 'description']]
my_errors['date'] = pd.to_datetime(my_errors['date'], format='%a %b %d %H:%M:%S.%f %Y')
my_errors.to_csv('errors.csv', index=False)